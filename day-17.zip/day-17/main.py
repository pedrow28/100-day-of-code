from question_model import Question
from data import question_data

# Creating question bank from question data

question_list = []

# Getting items from question_data

for item in question_data:
    question_text = item['text']
    question_answer = item['answer']
    question = Question(question_text, question_answer)
    question_list.append(question)

